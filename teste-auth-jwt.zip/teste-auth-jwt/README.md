# Canal Expertos Tech

**Vídeo tutorial:** </br>


**Redes Sociais:** https://linktr.ee/expertostech  

# PROJETO INICIAL - COMO CRIAR UM TOKEN JWT COM SPRING SECURITY, AUTH0 E JPA | JAVA E POSTGRESQL

**Nível:** Intermediário

Esse projeto foi desenvolvido no tutorial: Como criptografar senhas com Spring Boot, Spring Security e JPA<br> 
Playlist: https://youtu.be/YgfO8EHLAEc&list=PLTN1gMq8EHuIvkz0ZdFSufK-eI0FrnkvI

Será usado como base para o tutorial: Como criar um token JWT com Spring Boot, Spring Security e JPA.<br>
Para isso os pacotes e o nome do projeto foi renomeado.

Redes Sociais: https://linktr.ee/expertostech

=================  
NÃO CLIQUE AQUI: http://tiny.cc/1kzosz 
