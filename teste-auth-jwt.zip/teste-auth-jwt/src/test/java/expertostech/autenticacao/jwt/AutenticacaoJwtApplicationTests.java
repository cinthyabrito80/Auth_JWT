package expertostech.autenticacao.jwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutenticacaoJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
